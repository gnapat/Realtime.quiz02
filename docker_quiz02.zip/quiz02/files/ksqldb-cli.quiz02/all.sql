CREATE SOURCE CONNECTOR `postgres-source` WITH(
    "connector.class"='io.confluent.connect.jdbc.JdbcSourceConnector',
    "connection.url"='jdbc:postgresql://postgres.quiz0211:5432/root?user=root&password=secret',
    "mode"='incrementing',
    "incrementing.column.name"='id',
    "topic.prefix"='',
    "table.whitelist"='titles',
    "key"='id');

CREATE SOURCE CONNECTOR `postgres_test02` WITH(
    "connector.class"='io.confluent.connect.jdbc.JdbcSourceConnector',
    "connection.url"='jdbc:postgresql://postgres.quiz0211:5432/quiz0211_dev?user=root&password=secret',
    "mode"='incrementing',
    "incrementing.column.name"='index',
    "topic.prefix"='',
    "table.whitelist"='quiz0211_raw',
    "key"='index');


CREATE SOURCE CONNECTOR `postgres_quiz10` WITH(
    "connector.class"='io.confluent.connect.jdbc.JdbcSourceConnector',
    "connection.url"='jdbc:postgresql://postgres.quiz0211:5432/quiz0211_dev?user=root&password=secret',
    "mode"='incrementing',
    "incrementing.column.name"='index',
    "topic.prefix"='',
    "table.whitelist"='quiz0211_raw',
    "key"='index');



CREATE SINK CONNECTOR `elasticsearch-sink` WITH(
    "connector.class"='io.confluent.connect.elasticsearch.ElasticsearchSinkConnector',
    "connection.url"='http://elasticsearch:9200',
    "connection.username"='',
    "connection.password"='',
    "batch.size"='1',
    "write.method"='insert',
    "topics"='titles',
    "type.name"='changes',
    "key"='title_id');
