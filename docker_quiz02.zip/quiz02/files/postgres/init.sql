CREATE TABLE titles (
    id           SERIAL PRIMARY KEY,
    title        VARCHAR(120)
);

INSERT INTO titles (title) values ('Stranger Things');
INSERT INTO titles (title) values ('Black Mirror');
INSERT INTO titles (title) values ('The Office');
